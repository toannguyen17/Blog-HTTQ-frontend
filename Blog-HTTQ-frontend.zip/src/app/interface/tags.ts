export interface Tags {
    id?: number;
    content?: string;
    counter?: number;
}
