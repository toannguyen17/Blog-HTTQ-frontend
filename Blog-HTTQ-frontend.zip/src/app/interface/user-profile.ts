export interface UserProfile {
    id?: number;
    firstName?: string;
    lastName?: string;
    birthday?: any;
    gender?: string;
    address?: string;
    user_id?: number;
    avatar?: number;
}
