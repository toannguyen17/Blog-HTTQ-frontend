export interface Images {
    id?: number;
    fileName?: string;
    path?: string;
    user_id?: number;
}
