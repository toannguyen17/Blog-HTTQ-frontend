export interface BannedUsers {
    id?: number;
    created_at?: any;
    duration?: number;
    user_id?: number;
}
