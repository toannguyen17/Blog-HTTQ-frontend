export interface Permissions {
    id?: number;
    user_id?: number;
    role_id?: number;
}
