export interface Reactions {
    id?: number;
    type?: boolean;
    user_id?: number;
    post_id?: number;
}
