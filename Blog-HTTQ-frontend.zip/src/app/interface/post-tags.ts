export interface PostTags {
    id?: number;
    tag_id?: number;
    post_id?: number;
}
