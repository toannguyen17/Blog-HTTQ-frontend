export interface Comments {
    id?: number;
    content?: string;
    user_id?: number;
    post_id?: number;
}
