export interface BlockedUsers {
    id?: number;
    created_at?: any;
    user_id?: number;
}
