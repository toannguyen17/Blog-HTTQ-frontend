export interface Posts {
    id?: number;
    created_at?: any;
    title?: string;
    sub_title?: string;
    content?: string;
    content_plaintext?: string;
    status?: boolean;
    user_id?: number;
}
