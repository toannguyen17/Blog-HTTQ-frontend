export interface Roles {
    id?: number;
    name?: string;
    description?: string;
}
