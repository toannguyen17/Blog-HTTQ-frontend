export interface ISeek {
    type?: string;
    title?: string;
    description?: string;
    referenceId?: string;
    url?: string;
}
