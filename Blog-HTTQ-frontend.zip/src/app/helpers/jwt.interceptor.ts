import {Injectable}                                           from '@angular/core';
import {HttpRequest, HttpHandler, HttpEvent, HttpInterceptor} from '@angular/common/http';
import {Observable}                                           from 'rxjs';
import {AuthenticationService}                                from '../services/authentication.service';

@Injectable()
export class JwtInterceptor implements HttpInterceptor {
    constructor(private authenticationService: AuthenticationService) {
    }

    intercept(request: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
        // add auth header with jwt if user is logged in and request is to the api url
        let token = this.authenticationService.getToken();

        if (token) {
            request = request.clone({
                setHeaders: {Authorization: 'Bearer ' + this.authenticationService.getToken()}
            });
        }

        return next.handle(request);
    }
}
