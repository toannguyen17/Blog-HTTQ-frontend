export interface UserInfo {
    id?: number;
    firstName?: string;
    lastName?: string;
    gender?: string;
    phone?: string;
    address?: string;
    user_id?: number;
}
