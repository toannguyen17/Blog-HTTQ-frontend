
export interface ResImage {
    url: string;
}
