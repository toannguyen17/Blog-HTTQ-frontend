export class PostAuth {
    id?: number;
    thumbnail: string;
    firstName: string;
    lastName: string;
}
