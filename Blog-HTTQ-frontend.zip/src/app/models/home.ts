import {ReViewPost} from './reViewPost';

export class Home {
    topTrend: ReViewPost[];
    lastPost: ReViewPost[];
}
