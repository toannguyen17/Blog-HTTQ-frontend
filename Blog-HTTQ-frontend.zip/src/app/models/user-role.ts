export enum UserRole {
    ROLE_ADMIN,ROLE_USER
}
