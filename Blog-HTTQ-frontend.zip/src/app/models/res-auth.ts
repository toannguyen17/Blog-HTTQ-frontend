import {User} from './user';

export class ResAuth {
    user: User;
    token: string;
}
