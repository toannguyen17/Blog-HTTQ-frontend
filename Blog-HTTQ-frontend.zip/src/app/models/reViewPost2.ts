import {PostStatus} from './post-status';

export class ReViewPost2 {
    thumbnail: string;
    title: string;
    seo: string;
    contentPlainText: string;
    createdAt: Date;
    status: PostStatus;
}
