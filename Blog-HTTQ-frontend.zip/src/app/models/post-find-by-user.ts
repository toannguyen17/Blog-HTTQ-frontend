export class PostFindByUser {
    key?: string;
    page?: number;
    tags?: String[];
}
