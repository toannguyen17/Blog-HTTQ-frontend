export enum PostStatus {
    PRIVATE, PUBLIC
}
