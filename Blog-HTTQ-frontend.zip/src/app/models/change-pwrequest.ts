export interface ChangePWRequest {
    password?: string,
    newPassword?: string,
    confirmNewPassword?: string
}
