import { Component, OnInit, ViewEncapsulation } from '@angular/core';

@Component({
  selector: '.forbidden',
  templateUrl: './forbidden.component.html',
  encapsulation: ViewEncapsulation.None
})
export class ForbiddenComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
