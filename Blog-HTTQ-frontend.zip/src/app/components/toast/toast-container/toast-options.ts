export class ToastOptions {
    class?: string;
    autohide?: boolean;
    delay?: number;
    textOrTpl?: any;
}
